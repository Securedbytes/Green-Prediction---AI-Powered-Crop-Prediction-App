// integration_test/app_test.dart

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

// Import your main.dart file
import 'package:frontend/main.dart' as app;  // Adjust package name

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('Green Prediction App - UI Integration Tests', () {

    // Test 1: App launches successfully
    testWidgets('IT-UI-001: App should launch and display splash/home screen',
            (WidgetTester tester) async {
          // Launch the app
          app.main();
          await tester.pumpAndSettle();

          // Verify app loaded
          print('✅ IT-UI-001 PASSED: App launched successfully');

          // Take a screenshot
          await binding.takeScreenshot('01_app_launch');
        });

    // Test 2: Navigation to marketplace
    testWidgets('IT-UI-002: Should navigate to marketplace screen',
            (WidgetTester tester) async {
          app.main();
          await tester.pumpAndSettle();

          // Find and tap marketplace button
          final marketplaceButton = find.text('Marketplace');
          if (marketplaceButton.evaluate().isNotEmpty) {
            await tester.tap(marketplaceButton);
            await tester.pumpAndSettle();

            print('✅ IT-UI-002 PASSED: Navigated to marketplace');
            await binding.takeScreenshot('02_marketplace_screen');
          } else {
            print('⚠️ IT-UI-002: Marketplace button not found');
          }
        });

    // Test 3: Navigate to profile
    testWidgets('IT-UI-003: Should navigate to profile screen',
            (WidgetTester tester) async {
          app.main();
          await tester.pumpAndSettle();

          // Find and tap profile button
          final profileButton = find.text('Profile');
          if (profileButton.evaluate().isNotEmpty) {
            await tester.tap(profileButton);
            await tester.pumpAndSettle();

            print('✅ IT-UI-003 PASSED: Navigated to profile');
            await binding.takeScreenshot('03_profile_screen');
          }
        });

    // Test 4: Bottom navigation functionality
    testWidgets('IT-UI-004: Should switch between bottom navigation tabs',
            (WidgetTester tester) async {
          app.main();
          await tester.pumpAndSettle(Duration(seconds: 2));

          // Find bottom navigation items
          final homeNav = find.text('Home');
          final marketplaceNav = find.text('Marketplace');
          final profileNav = find.text('Profile');

          // Test navigation flow
          if (marketplaceNav.evaluate().isNotEmpty) {
            await tester.tap(marketplaceNav);
            await tester.pumpAndSettle();
            print('  → Tapped Marketplace tab');
          }

          if (profileNav.evaluate().isNotEmpty) {
            await tester.tap(profileNav);
            await tester.pumpAndSettle();
            print('  → Tapped Profile tab');
          }

          if (homeNav.evaluate().isNotEmpty) {
            await tester.tap(homeNav);
            await tester.pumpAndSettle();
            print('  → Tapped Home tab');
          }

          print('✅ IT-UI-004 PASSED: Bottom navigation works');
          await binding.takeScreenshot('04_navigation_complete');
        });

    // Test 5: Search functionality (if exists)
    testWidgets('IT-UI-005: Should handle search input',
            (WidgetTester tester) async {
          app.main();
          await tester.pumpAndSettle();

          // Look for search field
          final searchField = find.byType(TextField);

          if (searchField.evaluate().isNotEmpty) {
            await tester.enterText(searchField.first, 'Rice');
            await tester.pumpAndSettle();

            print('✅ IT-UI-005 PASSED: Search input works');
            await binding.takeScreenshot('05_search_test');
          } else {
            print('⚠️ IT-UI-005: Search field not found');
          }
        });

    // Test 6: Drawer menu (if exists)
    testWidgets('IT-UI-006: Should open and close drawer menu',
            (WidgetTester tester) async {
          app.main();
          await tester.pumpAndSettle();

          // Look for menu button
          final menuButton = find.byIcon(Icons.menu);

          if (menuButton.evaluate().isNotEmpty) {
            // Open drawer
            await tester.tap(menuButton);
            await tester.pumpAndSettle();
            print('  → Drawer opened');

            await binding.takeScreenshot('06_drawer_open');

            // Close drawer
            await tester.tap(find.byType(Scaffold).first);
            await tester.pumpAndSettle();

            print('✅ IT-UI-006 PASSED: Drawer functionality works');
          } else {
            print('⚠️ IT-UI-006: Menu button not found');
          }
        });

    // Test 7: Scroll functionality
    testWidgets('IT-UI-007: Should scroll through content',
            (WidgetTester tester) async {
          app.main();
          await tester.pumpAndSettle();

          // Find scrollable widget
          final scrollable = find.byType(Scrollable);

          if (scrollable.evaluate().isNotEmpty) {
            await tester.drag(scrollable.first, Offset(0, -300));
            await tester.pumpAndSettle();

            print('✅ IT-UI-007 PASSED: Scrolling works');
            await binding.takeScreenshot('07_scroll_test');
          } else {
            print('⚠️ IT-UI-007: Scrollable content not found');
          }
        });

    // Test 8: Button interactions
    testWidgets('IT-UI-008: Should respond to button taps',
            (WidgetTester tester) async {
          app.main();
          await tester.pumpAndSettle();

          // Find any ElevatedButton
          final button = find.byType(ElevatedButton);

          if (button.evaluate().isNotEmpty) {
            await tester.tap(button.first);
            await tester.pumpAndSettle();

            print('✅ IT-UI-008 PASSED: Button interactions work');
            await binding.takeScreenshot('08_button_test');
          } else {
            print('⚠️ IT-UI-008: No buttons found');
          }
        });

    // Test 9: App performance - loading time
    testWidgets('IT-UI-009: App should load within acceptable time',
            (WidgetTester tester) async {
          final stopwatch = Stopwatch()..start();

          app.main();
          await tester.pumpAndSettle();

          stopwatch.stop();
          final loadTime = stopwatch.elapsedMilliseconds;

          print('  → App load time: ${loadTime}ms');
          expect(loadTime, lessThan(5000), reason: 'App should load within 5 seconds');

          print('✅ IT-UI-009 PASSED: Load time acceptable (${loadTime}ms)');
        });

    // Test 10: Screen orientation handling
    testWidgets('IT-UI-010: Should handle screen rotation',
            (WidgetTester tester) async {
          app.main();
          await tester.pumpAndSettle();

          // Simulate screen rotation (portrait to landscape)
          await tester.binding.setSurfaceSize(Size(800, 600));
          await tester.pumpAndSettle();

          print('  → Screen rotated to landscape');
          await binding.takeScreenshot('10_landscape');

          // Rotate back to portrait
          await tester.binding.setSurfaceSize(Size(600, 800));
          await tester.pumpAndSettle();

          print('✅ IT-UI-010 PASSED: Screen orientation handled');
        });
  });
}