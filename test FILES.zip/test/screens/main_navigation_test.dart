// test/widget/screens/main_navigation_test.dart

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
// Import your files - adjust paths as needed
// import '../../../lib/screens/ui/main_navigation.dart';
// import '../../../lib/providers/auth_provider.dart';

void main() {
  group('MainNavigation Logic Tests', () {

    // Test 1: Farmer navigation items count
    test('WT-NAV-001: Should have 4 navigation items for farmers', () {
      // Arrange
      const farmerNavItems = [
        BottomNavigationBarItem(
          icon: Icon(Icons.home_outlined),
          activeIcon: Icon(Icons.home),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.psychology_outlined),
          activeIcon: Icon(Icons.psychology),
          label: 'AI Predict',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.store_outlined),
          activeIcon: Icon(Icons.store),
          label: 'Marketplace',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person_outline),
          activeIcon: Icon(Icons.person),
          label: 'Profile',
        ),
      ];

      // Assert
      expect(farmerNavItems.length, equals(4));
      expect(farmerNavItems[0].label, equals('Home'));
      expect(farmerNavItems[1].label, equals('AI Predict'));
      expect(farmerNavItems[2].label, equals('Marketplace'));
      expect(farmerNavItems[3].label, equals('Profile'));

      print('✅ WT-NAV-001 PASSED: Farmer has 4 navigation items');
    });

    // Test 2: Consumer navigation items count
    test('WT-NAV-002: Should have 3 navigation items for consumers', () {
      // Arrange
      const consumerNavItems = [
        BottomNavigationBarItem(
          icon: Icon(Icons.home_outlined),
          activeIcon: Icon(Icons.home),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.store_outlined),
          activeIcon: Icon(Icons.store),
          label: 'Marketplace',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person_outline),
          activeIcon: Icon(Icons.person),
          label: 'Profile',
        ),
      ];

      // Assert
      expect(consumerNavItems.length, equals(3));
      expect(consumerNavItems[0].label, equals('Home'));
      expect(consumerNavItems[1].label, equals('Marketplace'));
      expect(consumerNavItems[2].label, equals('Profile'));

      print('✅ WT-NAV-002 PASSED: Consumer has 3 navigation items');
    });

    // Test 3: Guest navigation items count
    test('WT-NAV-003: Should have 3 navigation items for guests', () {
      // Arrange
      const guestNavItems = [
        BottomNavigationBarItem(
          icon: Icon(Icons.home_outlined),
          activeIcon: Icon(Icons.home),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.store_outlined),
          activeIcon: Icon(Icons.store),
          label: 'Marketplace',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person_outline),
          activeIcon: Icon(Icons.person),
          label: 'Profile',
        ),
      ];

      // Assert
      expect(guestNavItems.length, equals(3));
      expect(guestNavItems[0].label, equals('Home'));
      expect(guestNavItems[1].label, equals('Marketplace'));
      expect(guestNavItems[2].label, equals('Profile'));

      print('✅ WT-NAV-003 PASSED: Guest has 3 navigation items');
    });

    // Test 4: Farmer has AI Predict tab
    test('WT-NAV-004: Should include AI Predict for farmers only', () {
      // Arrange
      const farmerItems = ['Home', 'AI Predict', 'Marketplace', 'Profile'];
      const consumerItems = ['Home', 'Marketplace', 'Profile'];
      const guestItems = ['Home', 'Marketplace', 'Profile'];

      // Assert
      expect(farmerItems, contains('AI Predict'));
      expect(consumerItems, isNot(contains('AI Predict')));
      expect(guestItems, isNot(contains('AI Predict')));

      print('✅ WT-NAV-004 PASSED: AI Predict exclusive to farmers');
    });

    // Test 5: All roles have Home
    test('WT-NAV-005: Should include Home for all user types', () {
      // Arrange
      const farmerItems = ['Home', 'AI Predict', 'Marketplace', 'Profile'];
      const consumerItems = ['Home', 'Marketplace', 'Profile'];
      const guestItems = ['Home', 'Marketplace', 'Profile'];

      // Assert
      expect(farmerItems, contains('Home'));
      expect(consumerItems, contains('Home'));
      expect(guestItems, contains('Home'));

      print('✅ WT-NAV-005 PASSED: Home available for all users');
    });

    // Test 6: All roles have Marketplace
    test('WT-NAV-006: Should include Marketplace for all user types', () {
      // Arrange
      const farmerItems = ['Home', 'AI Predict', 'Marketplace', 'Profile'];
      const consumerItems = ['Home', 'Marketplace', 'Profile'];
      const guestItems = ['Home', 'Marketplace', 'Profile'];

      // Assert
      expect(farmerItems, contains('Marketplace'));
      expect(consumerItems, contains('Marketplace'));
      expect(guestItems, contains('Marketplace'));

      print('✅ WT-NAV-006 PASSED: Marketplace available for all users');
    });

    // Test 7: All roles have Profile
    test('WT-NAV-007: Should include Profile for all user types', () {
      // Arrange
      const farmerItems = ['Home', 'AI Predict', 'Marketplace', 'Profile'];
      const consumerItems = ['Home', 'Marketplace', 'Profile'];
      const guestItems = ['Home', 'Marketplace', 'Profile'];

      // Assert
      expect(farmerItems, contains('Profile'));
      expect(consumerItems, contains('Profile'));
      expect(guestItems, contains('Profile'));

      print('✅ WT-NAV-007 PASSED: Profile available for all users');
    });

    // Test 8: Navigation index bounds for farmer
    test('WT-NAV-008: Should validate navigation index bounds for farmer', () {
      // Arrange
      const farmerScreenCount = 4; // Home, AI Predict, Marketplace, Profile
      final validIndices = [0, 1, 2, 3];

      // Assert
      for (var index in validIndices) {
        expect(index, lessThan(farmerScreenCount));
        expect(index, greaterThanOrEqualTo(0));
      }

      print('✅ WT-NAV-008 PASSED: Farmer navigation indices valid');
    });

    // Test 9: Navigation index bounds for consumer
    test('WT-NAV-009: Should validate navigation index bounds for consumer', () {
      // Arrange
      const consumerScreenCount = 3; // Home, Marketplace, Profile
      final validIndices = [0, 1, 2];

      // Assert
      for (var index in validIndices) {
        expect(index, lessThan(consumerScreenCount));
        expect(index, greaterThanOrEqualTo(0));
      }

      print('✅ WT-NAV-009 PASSED: Consumer navigation indices valid');
    });

    // Test 10: Navigation icons are distinct
    test('WT-NAV-010: Should have distinct icons for each navigation item', () {
      // Arrange
      final farmerIcons = [
        Icons.home_outlined,
        Icons.psychology_outlined,
        Icons.store_outlined,
        Icons.person_outline,
      ];

      // Assert
      final uniqueIcons = farmerIcons.toSet();
      expect(uniqueIcons.length, equals(farmerIcons.length));

      print('✅ WT-NAV-010 PASSED: All navigation icons are distinct');
    });

    // Test 11: Active and inactive icon pairs
    test('WT-NAV-011: Should have matching active/inactive icon pairs', () {
      // Arrange
      final iconPairs = [
        {'inactive': Icons.home_outlined, 'active': Icons.home},
        {'inactive': Icons.psychology_outlined, 'active': Icons.psychology},
        {'inactive': Icons.store_outlined, 'active': Icons.store},
        {'inactive': Icons.person_outline, 'active': Icons.person},
      ];

      // Assert
      expect(iconPairs.length, equals(4));
      for (var pair in iconPairs) {
        expect(pair.containsKey('inactive'), isTrue);
        expect(pair.containsKey('active'), isTrue);
      }

      print('✅ WT-NAV-011 PASSED: Icon pairs configured correctly');
    });

    // Test 12: Screen count matches navigation items for farmer
    test('WT-NAV-012: Should have equal screens and nav items for farmer', () {
      // Arrange
      const farmerScreens = 4; // HomeScreen, AIPredictionScreen, MarketplaceScreen, ProfileScreen
      const farmerNavItems = 4;

      // Assert
      expect(farmerScreens, equals(farmerNavItems));

      print('✅ WT-NAV-012 PASSED: Farmer screens match nav items');
    });

    // Test 13: Screen count matches navigation items for consumer
    test('WT-NAV-013: Should have equal screens and nav items for consumer', () {
      // Arrange
      const consumerScreens = 3; // HomeScreen, MarketplaceScreen, ProfileScreen
      const consumerNavItems = 3;

      // Assert
      expect(consumerScreens, equals(consumerNavItems));

      print('✅ WT-NAV-013 PASSED: Consumer screens match nav items');
    });

    // Test 14: Index adjustment when switching roles
    test('WT-NAV-014: Should reset index when switching from farmer to consumer', () {
      // Arrange
      int currentIndex = 3; // Was on Profile (index 3) as farmer
      const consumerScreenCount = 3;

      // Act - Simulate role switch
      if (currentIndex >= consumerScreenCount) {
        currentIndex = 0;
      }

      // Assert
      expect(currentIndex, equals(0));

      print('✅ WT-NAV-014 PASSED: Index resets when exceeding screen count');
    });

    // Test 15: Valid index doesn't reset when switching roles
    test('WT-NAV-015: Should preserve valid index when switching roles', () {
      // Arrange
      int currentIndex = 1; // On Marketplace
      const consumerScreenCount = 3;

      // Act - Simulate role switch
      if (currentIndex >= consumerScreenCount) {
        currentIndex = 0;
      }

      // Assert
      expect(currentIndex, equals(1)); // Should stay at 1

      print('✅ WT-NAV-015 PASSED: Valid index preserved across role switch');
    });

    // Test 16: Navigation label validation
    test('WT-NAV-016: Should have non-empty labels for all nav items', () {
      // Arrange
      const labels = ['Home', 'AI Predict', 'Marketplace', 'Profile'];

      // Assert
      for (var label in labels) {
        expect(label, isNotEmpty);
        expect(label.length, greaterThan(0));
      }

      print('✅ WT-NAV-016 PASSED: All navigation labels are valid');
    });

    // Test 17: Consumer and guest have same navigation
    test('WT-NAV-017: Should have identical navigation for consumer and guest', () {
      // Arrange
      const consumerItems = ['Home', 'Marketplace', 'Profile'];
      const guestItems = ['Home', 'Marketplace', 'Profile'];

      // Assert
      expect(consumerItems, equals(guestItems));

      print('✅ WT-NAV-017 PASSED: Consumer and guest navigation identical');
    });

    // Test 18: Farmer-specific screen position
    test('WT-NAV-018: Should have AI Predict at index 1 for farmers', () {
      // Arrange
      const farmerNavLabels = ['Home', 'AI Predict', 'Marketplace', 'Profile'];
      const aiPredictIndex = 1;

      // Assert
      expect(farmerNavLabels[aiPredictIndex], equals('AI Predict'));

      print('✅ WT-NAV-018 PASSED: AI Predict positioned correctly');
    });

    // Test 19: Home always at index 0
    test('WT-NAV-019: Should have Home at index 0 for all user types', () {
      // Arrange
      const farmerItems = ['Home', 'AI Predict', 'Marketplace', 'Profile'];
      const consumerItems = ['Home', 'Marketplace', 'Profile'];
      const guestItems = ['Home', 'Marketplace', 'Profile'];

      // Assert
      expect(farmerItems[0], equals('Home'));
      expect(consumerItems[0], equals('Home'));
      expect(guestItems[0], equals('Home'));

      print('✅ WT-NAV-019 PASSED: Home always at first position');
    });

    // Test 20: Profile always at last index
    test('WT-NAV-020: Should have Profile at last index for all user types', () {
      // Arrange
      const farmerItems = ['Home', 'AI Predict', 'Marketplace', 'Profile'];
      const consumerItems = ['Home', 'Marketplace', 'Profile'];
      const guestItems = ['Home', 'Marketplace', 'Profile'];

      // Assert
      expect(farmerItems.last, equals('Profile'));
      expect(consumerItems.last, equals('Profile'));
      expect(guestItems.last, equals('Profile'));

      print('✅ WT-NAV-020 PASSED: Profile always at last position');
    });
  });

  group('MainNavigation Index Management Tests', () {

    // Test 21: Initial index should be 0
    test('WT-NAV-021: Should initialize with index 0', () {
      // Arrange
      const initialIndex = 0;

      // Assert
      expect(initialIndex, equals(0));

      print('✅ WT-NAV-021 PASSED: Initial index is 0');
    });

    // Test 22: Index increment validation
    test('WT-NAV-022: Should handle index changes correctly', () {
      // Arrange
      int currentIndex = 0;
      const maxIndex = 3;

      // Act & Assert - Valid increments
      currentIndex = 1;
      expect(currentIndex, lessThanOrEqualTo(maxIndex));

      currentIndex = 2;
      expect(currentIndex, lessThanOrEqualTo(maxIndex));

      currentIndex = 3;
      expect(currentIndex, lessThanOrEqualTo(maxIndex));

      print('✅ WT-NAV-022 PASSED: Index changes validated');
    });

    // Test 23: Index boundary check
    test('WT-NAV-023: Should prevent out-of-bounds index', () {
      // Arrange
      int currentIndex = 5; // Invalid index
      const screenCount = 4;

      // Act - Boundary check
      if (currentIndex >= screenCount) {
        currentIndex = 0;
      }

      // Assert
      expect(currentIndex, equals(0));
      expect(currentIndex, lessThan(screenCount));

      print('✅ WT-NAV-023 PASSED: Out-of-bounds index prevented');
    });

    // Test 24: Negative index handling
    test('WT-NAV-024: Should handle negative index by resetting to 0', () {
      // Arrange
      int currentIndex = -1; // Invalid negative index
      const screenCount = 4;

      // Act - Validation
      if (currentIndex < 0 || currentIndex >= screenCount) {
        currentIndex = 0;
      }

      // Assert
      expect(currentIndex, equals(0));
      expect(currentIndex, greaterThanOrEqualTo(0));

      print('✅ WT-NAV-024 PASSED: Negative index handled correctly');
    });
  });

  group('MainNavigation Role-Based Access Tests', () {

    // Test 25: Farmer can access all 4 screens
    test('WT-NAV-025: Should allow farmer to access all 4 screens', () {
      // Arrange
      const isFarmer = true;
      const screenCount = isFarmer ? 4 : 3;

      // Assert
      expect(screenCount, equals(4));

      print('✅ WT-NAV-025 PASSED: Farmer can access 4 screens');
    });

    // Test 26: Consumer can access 3 screens
    test('WT-NAV-026: Should allow consumer to access 3 screens', () {
      // Arrange
      const isFarmer = false;
      const isGuest = false;
      const screenCount = isFarmer ? 4 : 3;

      // Assert
      expect(screenCount, equals(3));

      print('✅ WT-NAV-026 PASSED: Consumer can access 3 screens');
    });

    // Test 27: Guest can access 3 screens
    test('WT-NAV-027: Should allow guest to access 3 screens', () {
      // Arrange
      const isGuest = true;
      const screenCount = isGuest ? 3 : 4;

      // Assert
      expect(screenCount, equals(3));

      print('✅ WT-NAV-027 PASSED: Guest can access 3 screens');
    });

    // Test 28: Screen access based on authentication
    test('WT-NAV-028: Should determine screen count based on user role', () {
      // Arrange & Act
      final farmerScreens = _getScreenCountForRole(isFarmer: true, isGuest: false);
      final consumerScreens = _getScreenCountForRole(isFarmer: false, isGuest: false);
      final guestScreens = _getScreenCountForRole(isFarmer: false, isGuest: true);

      // Assert
      expect(farmerScreens, equals(4));
      expect(consumerScreens, equals(3));
      expect(guestScreens, equals(3));

      print('✅ WT-NAV-028 PASSED: Screen count determined by role');
    });
  });
}

// Helper function for test
int _getScreenCountForRole({required bool isFarmer, required bool isGuest}) {
  if (isGuest) {
    return 3; // Guest screens
  }
  return isFarmer ? 4 : 3;
}