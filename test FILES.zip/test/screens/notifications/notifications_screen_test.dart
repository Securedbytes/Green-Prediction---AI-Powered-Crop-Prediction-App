// test/models/notification_item_test.dart

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
// Import your notifications screen file - adjust path as needed
// import '../../lib/screens/notifications/notifications_screen.dart';

void main() {
  group('NotificationItem Model Tests', () {

    // Test 1: Create inquiry notification with avatar
    test('UT-MOD-045: Should create inquiry notification with avatar', () {
      // Arrange & Act
      final notification = NotificationItem(
        id: 'NTF001',
        type: NotificationType.inquiry,
        title: 'New Product Inquiry',
        message: 'Sarah Johnson is interested in your organic tomatoes.',
        time: '2 minutes ago',
        isRead: false,
        avatar: 'SJ',
      );

      // Assert
      expect(notification.id, equals('NTF001'));
      expect(notification.type, equals(NotificationType.inquiry));
      expect(notification.title, equals('New Product Inquiry'));
      expect(notification.message, equals('Sarah Johnson is interested in your organic tomatoes.'));
      expect(notification.time, equals('2 minutes ago'));
      expect(notification.isRead, isFalse);
      expect(notification.avatar, equals('SJ'));
      expect(notification.icon, isNull);

      print('✅ UT-MOD-045 PASSED: Inquiry notification with avatar created');
    });

    // Test 2: Create system notification with icon
    test('UT-MOD-046: Should create system notification with icon', () {
      // Arrange & Act
      final notification = NotificationItem(
        id: 'NTF002',
        type: NotificationType.system,
        title: 'Weather Alert',
        message: 'Heavy rain expected tomorrow.',
        time: '1 hour ago',
        isRead: false,
        icon: Icons.cloudy_snowing,
      );

      // Assert
      expect(notification.id, equals('NTF002'));
      expect(notification.type, equals(NotificationType.system));
      expect(notification.title, equals('Weather Alert'));
      expect(notification.message, equals('Heavy rain expected tomorrow.'));
      expect(notification.time, equals('1 hour ago'));
      expect(notification.isRead, isFalse);
      expect(notification.icon, equals(Icons.cloudy_snowing));
      expect(notification.avatar, isNull);

      print('✅ UT-MOD-046 PASSED: System notification with icon created');
    });

    // Test 3: Create order notification
    test('UT-MOD-047: Should create order notification', () {
      // Arrange & Act
      final notification = NotificationItem(
        id: 'NTF003',
        type: NotificationType.order,
        title: 'Order Confirmed',
        message: 'Your order of fresh vegetables has been confirmed.',
        time: '2 hours ago',
        isRead: true,
        icon: Icons.check_circle,
      );

      // Assert
      expect(notification.id, equals('NTF003'));
      expect(notification.type, equals(NotificationType.order));
      expect(notification.title, equals('Order Confirmed'));
      expect(notification.isRead, isTrue);
      expect(notification.icon, equals(Icons.check_circle));

      print('✅ UT-MOD-047 PASSED: Order notification created');
    });

    // Test 4: Toggle isRead status
    test('UT-MOD-048: Should toggle isRead status', () {
      // Arrange
      final notification = NotificationItem(
        id: 'NTF004',
        type: NotificationType.inquiry,
        title: 'Chat Message',
        message: 'New message from user',
        time: '5 minutes ago',
        isRead: false,
      );

      // Act
      expect(notification.isRead, isFalse);
      notification.isRead = true;

      // Assert
      expect(notification.isRead, isTrue);

      print('✅ UT-MOD-048 PASSED: isRead status toggled successfully');
    });

    // Test 5: Create notification without optional fields
    test('UT-MOD-049: Should create notification without avatar and icon', () {
      // Arrange & Act
      final notification = NotificationItem(
        id: 'NTF005',
        type: NotificationType.system,
        title: 'System Update',
        message: 'New features available',
        time: '1 day ago',
        isRead: true,
      );

      // Assert
      expect(notification.id, equals('NTF005'));
      expect(notification.avatar, isNull);
      expect(notification.icon, isNull);

      print('✅ UT-MOD-049 PASSED: Notification created without optional fields');
    });

    // Test 6: Verify unique notification IDs
    test('UT-MOD-050: Should support unique notification IDs', () {
      // Arrange & Act
      final notification1 = NotificationItem(
        id: 'NTF_UNIQUE_001',
        type: NotificationType.inquiry,
        title: 'First',
        message: 'Message 1',
        time: 'now',
        isRead: false,
      );

      final notification2 = NotificationItem(
        id: 'NTF_UNIQUE_002',
        type: NotificationType.inquiry,
        title: 'Second',
        message: 'Message 2',
        time: 'now',
        isRead: false,
      );

      // Assert
      expect(notification1.id, isNot(equals(notification2.id)));
      expect(notification1.id, equals('NTF_UNIQUE_001'));
      expect(notification2.id, equals('NTF_UNIQUE_002'));

      print('✅ UT-MOD-050 PASSED: Unique notification IDs supported');
    });

    // Test 7: Handle long messages
    test('UT-MOD-051: Should handle long notification messages', () {
      // Arrange
      final longMessage = 'This is a very long notification message that contains ' +
          'a lot of information about the order, including details about ' +
          'the products, delivery information, and payment status. ' +
          'It should be handled properly without any issues.';

      // Act
      final notification = NotificationItem(
        id: 'NTF006',
        type: NotificationType.order,
        title: 'Order Update',
        message: longMessage,
        time: '30 minutes ago',
        isRead: false,
        icon: Icons.shopping_cart,
      );

      // Assert
      expect(notification.message, equals(longMessage));
      expect(notification.message.length, greaterThan(100));

      print('✅ UT-MOD-051 PASSED: Long messages handled correctly');
    });

    // Test 8: Handle special characters in messages
    test('UT-MOD-052: Should handle special characters in messages', () {
      // Arrange & Act
      final notification = NotificationItem(
        id: 'NTF007',
        type: NotificationType.inquiry,
        title: 'Question: "Are these organic?"',
        message: 'User asked: "Are these 100% organic & pesticide-free vegetables?"',
        time: '10 minutes ago',
        isRead: false,
        avatar: 'AB',
      );

      // Assert
      expect(notification.title, contains('"'));
      expect(notification.message, contains('&'));
      expect(notification.message, contains('?'));

      print('✅ UT-MOD-052 PASSED: Special characters handled correctly');
    });

    // Test 9: Time format variations
    test('UT-MOD-053: Should support various time format strings', () {
      // Arrange & Act
      final notification1 = NotificationItem(
        id: 'NTF008',
        type: NotificationType.system,
        title: 'Alert 1',
        message: 'Message 1',
        time: '2 minutes ago',
        isRead: false,
      );

      final notification2 = NotificationItem(
        id: 'NTF009',
        type: NotificationType.system,
        title: 'Alert 2',
        message: 'Message 2',
        time: '3 hours ago',
        isRead: false,
      );

      final notification3 = NotificationItem(
        id: 'NTF010',
        type: NotificationType.system,
        title: 'Alert 3',
        message: 'Message 3',
        time: '2 days ago',
        isRead: false,
      );

      // Assert
      expect(notification1.time, equals('2 minutes ago'));
      expect(notification2.time, equals('3 hours ago'));
      expect(notification3.time, equals('2 days ago'));

      print('✅ UT-MOD-053 PASSED: Various time formats supported');
    });

    // Test 10: Avatar initials variations
    test('UT-MOD-054: Should support different avatar initial formats', () {
      // Arrange & Act
      final notification1 = NotificationItem(
        id: 'NTF011',
        type: NotificationType.inquiry,
        title: 'Message from Sarah',
        message: 'Hello',
        time: 'now',
        isRead: false,
        avatar: 'SJ', // Two initials
      );

      final notification2 = NotificationItem(
        id: 'NTF012',
        type: NotificationType.inquiry,
        title: 'Message from Bob',
        message: 'Hi',
        time: 'now',
        isRead: false,
        avatar: 'B', // Single initial
      );

      final notification3 = NotificationItem(
        id: 'NTF013',
        type: NotificationType.inquiry,
        title: 'Message from Alice',
        message: 'Hey',
        time: 'now',
        isRead: false,
        avatar: 'ABC', // Three initials
      );

      // Assert
      expect(notification1.avatar, equals('SJ'));
      expect(notification2.avatar, equals('B'));
      expect(notification3.avatar, equals('ABC'));

      print('✅ UT-MOD-054 PASSED: Different avatar formats supported');
    });

    // Test 11: Mark multiple notifications as read
    test('UT-MOD-055: Should mark multiple notifications as read', () {
      // Arrange
      final notifications = [
        NotificationItem(
          id: 'NTF014',
          type: NotificationType.inquiry,
          title: 'Notification 1',
          message: 'Message 1',
          time: 'now',
          isRead: false,
        ),
        NotificationItem(
          id: 'NTF015',
          type: NotificationType.system,
          title: 'Notification 2',
          message: 'Message 2',
          time: 'now',
          isRead: false,
        ),
        NotificationItem(
          id: 'NTF016',
          type: NotificationType.order,
          title: 'Notification 3',
          message: 'Message 3',
          time: 'now',
          isRead: false,
        ),
      ];

      // Act
      for (var notification in notifications) {
        notification.isRead = true;
      }

      // Assert
      expect(notifications.every((n) => n.isRead), isTrue);

      print('✅ UT-MOD-055 PASSED: Multiple notifications marked as read');
    });

    // Test 12: Filter unread notifications
    test('UT-MOD-056: Should identify unread notifications', () {
      // Arrange
      final notifications = [
        NotificationItem(
          id: 'NTF017',
          type: NotificationType.inquiry,
          title: 'Unread 1',
          message: 'Message 1',
          time: 'now',
          isRead: false,
        ),
        NotificationItem(
          id: 'NTF018',
          type: NotificationType.system,
          title: 'Read 1',
          message: 'Message 2',
          time: 'now',
          isRead: true,
        ),
        NotificationItem(
          id: 'NTF019',
          type: NotificationType.order,
          title: 'Unread 2',
          message: 'Message 3',
          time: 'now',
          isRead: false,
        ),
      ];

      // Act
      final unreadNotifications = notifications.where((n) => !n.isRead).toList();

      // Assert
      expect(unreadNotifications.length, equals(2));
      expect(unreadNotifications[0].id, equals('NTF017'));
      expect(unreadNotifications[1].id, equals('NTF019'));

      print('✅ UT-MOD-056 PASSED: Unread notifications identified correctly');
    });
  });

  group('NotificationType Enum Tests', () {

    // Test 13: Verify all notification types
    test('UT-MOD-057: Should have all three notification types', () {
      // Arrange & Act
      final types = NotificationType.values;

      // Assert
      expect(types.length, equals(3));
      expect(types, contains(NotificationType.inquiry));
      expect(types, contains(NotificationType.system));
      expect(types, contains(NotificationType.order));

      print('✅ UT-MOD-057 PASSED: All notification types exist');
    });

    // Test 14: Notification type equality
    test('UT-MOD-058: Should compare notification types correctly', () {
      // Arrange
      final type1 = NotificationType.inquiry;
      final type2 = NotificationType.inquiry;
      final type3 = NotificationType.system;

      // Assert
      expect(type1, equals(type2));
      expect(type1, isNot(equals(type3)));

      print('✅ UT-MOD-058 PASSED: Notification type equality works');
    });

    // Test 15: Filter by notification type
    test('UT-MOD-059: Should filter notifications by type', () {
      // Arrange
      final notifications = [
        NotificationItem(
          id: 'NTF020',
          type: NotificationType.inquiry,
          title: 'Inquiry 1',
          message: 'Message 1',
          time: 'now',
          isRead: false,
        ),
        NotificationItem(
          id: 'NTF021',
          type: NotificationType.system,
          title: 'System 1',
          message: 'Message 2',
          time: 'now',
          isRead: false,
        ),
        NotificationItem(
          id: 'NTF022',
          type: NotificationType.inquiry,
          title: 'Inquiry 2',
          message: 'Message 3',
          time: 'now',
          isRead: false,
        ),
        NotificationItem(
          id: 'NTF023',
          type: NotificationType.order,
          title: 'Order 1',
          message: 'Message 4',
          time: 'now',
          isRead: false,
        ),
      ];

      // Act
      final inquiryNotifications = notifications.where((n) => n.type == NotificationType.inquiry).toList();
      final systemNotifications = notifications.where((n) => n.type == NotificationType.system).toList();
      final orderNotifications = notifications.where((n) => n.type == NotificationType.order).toList();

      // Assert
      expect(inquiryNotifications.length, equals(2));
      expect(systemNotifications.length, equals(1));
      expect(orderNotifications.length, equals(1));

      print('✅ UT-MOD-059 PASSED: Notifications filtered by type correctly');
    });

    // Test 16: Notification type in switch statement
    test('UT-MOD-060: Should work correctly in switch statements', () {
      // Arrange
      final notification = NotificationItem(
        id: 'NTF024',
        type: NotificationType.system,
        title: 'System Alert',
        message: 'Test message',
        time: 'now',
        isRead: false,
      );

      // Act
      String category;
      switch (notification.type) {
        case NotificationType.inquiry:
          category = 'Inquiry';
          break;
        case NotificationType.system:
          category = 'System';
          break;
        case NotificationType.order:
          category = 'Order';
          break;
      }

      // Assert
      expect(category, equals('System'));

      print('✅ UT-MOD-060 PASSED: Notification type works in switch statement');
    });
  });

  group('Notification List Operations', () {

    // Test 17: Add notification to list
    test('UT-MOD-061: Should add notification to list', () {
      // Arrange
      final notifications = <NotificationItem>[];
      final newNotification = NotificationItem(
        id: 'NTF025',
        type: NotificationType.inquiry,
        title: 'New Inquiry',
        message: 'New message',
        time: 'just now',
        isRead: false,
      );

      // Act
      notifications.add(newNotification);

      // Assert
      expect(notifications.length, equals(1));
      expect(notifications.first.id, equals('NTF025'));

      print('✅ UT-MOD-061 PASSED: Notification added to list');
    });

    // Test 18: Remove notification from list
    test('UT-MOD-062: Should remove notification from list', () {
      // Arrange
      final notification1 = NotificationItem(
        id: 'NTF026',
        type: NotificationType.inquiry,
        title: 'Notification 1',
        message: 'Message 1',
        time: 'now',
        isRead: false,
      );
      final notification2 = NotificationItem(
        id: 'NTF027',
        type: NotificationType.system,
        title: 'Notification 2',
        message: 'Message 2',
        time: 'now',
        isRead: false,
      );
      final notifications = [notification1, notification2];

      // Act
      notifications.remove(notification1);

      // Assert
      expect(notifications.length, equals(1));
      expect(notifications.first.id, equals('NTF027'));

      print('✅ UT-MOD-062 PASSED: Notification removed from list');
    });

    // Test 19: Find notification by ID
    test('UT-MOD-063: Should find notification by ID', () {
      // Arrange
      final notifications = [
        NotificationItem(
          id: 'NTF028',
          type: NotificationType.inquiry,
          title: 'Notification 1',
          message: 'Message 1',
          time: 'now',
          isRead: false,
        ),
        NotificationItem(
          id: 'NTF029',
          type: NotificationType.system,
          title: 'Notification 2',
          message: 'Message 2',
          time: 'now',
          isRead: false,
        ),
      ];

      // Act
      final found = notifications.firstWhere((n) => n.id == 'NTF029');

      // Assert
      expect(found.id, equals('NTF029'));
      expect(found.title, equals('Notification 2'));

      print('✅ UT-MOD-063 PASSED: Notification found by ID');
    });

    // Test 20: Count unread notifications
    test('UT-MOD-064: Should count unread notifications', () {
      // Arrange
      final notifications = [
        NotificationItem(id: 'NTF030', type: NotificationType.inquiry, title: 'N1', message: 'M1', time: 'now', isRead: false),
        NotificationItem(id: 'NTF031', type: NotificationType.system, title: 'N2', message: 'M2', time: 'now', isRead: true),
        NotificationItem(id: 'NTF032', type: NotificationType.order, title: 'N3', message: 'M3', time: 'now', isRead: false),
        NotificationItem(id: 'NTF033', type: NotificationType.inquiry, title: 'N4', message: 'M4', time: 'now', isRead: false),
      ];

      // Act
      final unreadCount = notifications.where((n) => !n.isRead).length;

      // Assert
      expect(unreadCount, equals(3));

      print('✅ UT-MOD-064 PASSED: Unread notifications counted correctly');
    });
  });
}