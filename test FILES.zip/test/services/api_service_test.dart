// test/services/api_service_test.dart

import 'package:flutter_test/flutter_test.dart';
// Import your api_service file - adjust path as needed
// import '../../lib/services/api_service.dart';

void main() {
  group('ApiService Configuration Tests', () {

    // Test 1: Base URL configuration
    test('UT-API-001: Should have correct base URL', () {
      // Arrange
      const expectedBaseUrl = 'http://192.168.1.157:8001';

      // Assert
      expect(ApiService.baseUrl, equals(expectedBaseUrl));
      expect(ApiService.baseUrl, isNotEmpty);
      expect(ApiService.baseUrl, startsWith('http'));

      print('✅ UT-API-001 PASSED: Base URL configured correctly');
    });

    // Test 2: Default headers configuration
    test('UT-API-002: Should have correct default headers', () {
      // Arrange
      final apiService = ApiService();
      final headers = apiService._headers;

      // Assert
      expect(headers['Content-Type'], equals('application/json'));
      expect(headers['Accept'], equals('application/json'));
      expect(headers.length, equals(2));

      print('✅ UT-API-002 PASSED: Default headers configured correctly');
    });

    // Test 3: Auth headers include Bearer token
    test('UT-API-003: Should include Bearer token in auth headers', () {
      // Arrange
      final apiService = ApiService();
      const testToken = 'test_token_12345678901234567890';

      // Act
      final authHeaders = apiService._authHeaders(testToken);

      // Assert
      expect(authHeaders['Authorization'], equals('Bearer $testToken'));
      expect(authHeaders['Content-Type'], equals('application/json'));
      expect(authHeaders['Accept'], equals('application/json'));
      expect(authHeaders.containsKey('Authorization'), isTrue);

      print('✅ UT-API-003 PASSED: Auth headers include Bearer token');
    });

    // Test 4: Auth headers preserve default headers
    test('UT-API-004: Should preserve default headers in auth headers', () {
      // Arrange
      final apiService = ApiService();
      const testToken = 'sample_token';

      // Act
      final authHeaders = apiService._authHeaders(testToken);

      // Assert
      expect(authHeaders['Content-Type'], equals('application/json'));
      expect(authHeaders['Accept'], equals('application/json'));
      expect(authHeaders.length, equals(3)); // Content-Type, Accept, Authorization

      print('✅ UT-API-004 PASSED: Default headers preserved in auth headers');
    });
  });

  group('API Endpoint Tests', () {

    // Test 5: Auth endpoint configuration
    test('UT-API-005: Should have correct auth endpoint', () {
      // Arrange
      const authEndpoint = '/auth';
      const expectedLoginUrl = '${ApiService.baseUrl}$authEndpoint/login';
      const expectedRegisterUrl = '${ApiService.baseUrl}$authEndpoint/register';

      // Assert
      expect(expectedLoginUrl, equals('http://192.168.1.157:8001/auth/login'));
      expect(expectedRegisterUrl, equals('http://192.168.1.157:8001/auth/register'));

      print('✅ UT-API-005 PASSED: Auth endpoints correct');
    });

    // Test 6: Listings endpoint configuration
    test('UT-API-006: Should have correct listings endpoint', () {
      // Arrange
      const listingsEndpoint = '/listings';
      const expectedListingsUrl = '${ApiService.baseUrl}$listingsEndpoint';

      // Assert
      expect(expectedListingsUrl, equals('http://192.168.1.157:8001/listings'));

      print('✅ UT-API-006 PASSED: Listings endpoint correct');
    });

    // Test 7: Profile endpoint configuration
    test('UT-API-007: Should have correct profile endpoint', () {
      // Arrange
      const profileEndpoint = '/profile/';
      const expectedProfileUrl = '${ApiService.baseUrl}$profileEndpoint';

      // Assert
      expect(expectedProfileUrl, equals('http://192.168.1.157:8001/profile/'));

      print('✅ UT-API-007 PASSED: Profile endpoint correct');
    });

    // Test 8: Predictions endpoint
    test('UT-API-008: Should construct correct predictions endpoint', () {
      // Arrange
      const predictionsUrl = '${ApiService.baseUrl}/predictions/analyze';

      // Assert
      expect(predictionsUrl, equals('http://192.168.1.157:8001/predictions/analyze'));

      print('✅ UT-API-008 PASSED: Predictions endpoint correct');
    });

    // Test 9: Inquiries endpoint
    test('UT-API-009: Should construct correct inquiries endpoint', () {
      // Arrange
      const inquiriesUrl = '${ApiService.baseUrl}/api/inquiries';

      // Assert
      expect(inquiriesUrl, equals('http://192.168.1.157:8001/api/inquiries'));

      print('✅ UT-API-009 PASSED: Inquiries endpoint correct');
    });
  });

  group('Query Parameter Construction Tests', () {

    // Test 10: Single query parameter
    test('UT-API-010: Should construct single query parameter correctly', () {
      // Arrange
      const cropType = 'Rice';
      final params = ['crop_type=$cropType'];
      final queryParams = '?${params.join('&')}';

      // Assert
      expect(queryParams, equals('?crop_type=Rice'));

      print('✅ UT-API-010 PASSED: Single query parameter constructed');
    });

    // Test 11: Multiple query parameters
    test('UT-API-011: Should construct multiple query parameters correctly', () {
      // Arrange
      final params = ['crop_type=Rice', 'location=Colombo', 'is_organic=true'];
      final queryParams = '?${params.join('&')}';

      // Assert
      expect(queryParams, equals('?crop_type=Rice&location=Colombo&is_organic=true'));
      expect(queryParams, contains('crop_type=Rice'));
      expect(queryParams, contains('location=Colombo'));
      expect(queryParams, contains('is_organic=true'));

      print('✅ UT-API-011 PASSED: Multiple query parameters constructed');
    });

    // Test 12: Query parameters with numeric values
    test('UT-API-012: Should handle numeric query parameters', () {
      // Arrange
      final params = ['price_min=100', 'price_max=500', 'limit=20', 'offset=0'];
      final queryParams = '?${params.join('&')}';

      // Assert
      expect(queryParams, contains('price_min=100'));
      expect(queryParams, contains('price_max=500'));
      expect(queryParams, contains('limit=20'));
      expect(queryParams, contains('offset=0'));

      print('✅ UT-API-012 PASSED: Numeric query parameters handled');
    });

    // Test 13: Empty query parameters
    test('UT-API-013: Should handle empty query parameters list', () {
      // Arrange
      final params = <String>[];
      String queryParams = '';
      if (params.isNotEmpty) {
        queryParams = '?${params.join('&')}';
      }

      // Assert
      expect(queryParams, isEmpty);

      print('✅ UT-API-013 PASSED: Empty query parameters handled');
    });

    // Test 14: Query parameter encoding
    test('UT-API-014: Should construct query with special characters', () {
      // Arrange
      final params = ['location=Colombo 01', 'crop_type=Green Beans'];
      final queryParams = '?${params.join('&')}';

      // Assert
      expect(queryParams, contains('location='));
      expect(queryParams, contains('crop_type='));

      print('✅ UT-API-014 PASSED: Special characters in query params handled');
    });
  });

  group('URL Construction Tests', () {

    // Test 15: Listing by ID URL
    test('UT-API-015: Should construct listing by ID URL correctly', () {
      // Arrange
      const listingId = 'LST001';
      final url = '${ApiService.baseUrl}/listings/$listingId';

      // Assert
      expect(url, equals('http://192.168.1.157:8001/listings/LST001'));

      print('✅ UT-API-015 PASSED: Listing by ID URL constructed');
    });

    // Test 16: Farmer listings URL
    test('UT-API-016: Should construct farmer listings URL correctly', () {
      // Arrange
      const farmerId = 'FARMER123';
      final url = '${ApiService.baseUrl}/listings/farmer/$farmerId';

      // Assert
      expect(url, equals('http://192.168.1.157:8001/listings/farmer/FARMER123'));

      print('✅ UT-API-016 PASSED: Farmer listings URL constructed');
    });

    // Test 17: My listings URL
    test('UT-API-017: Should construct my listings URL correctly', () {
      // Arrange
      final url = '${ApiService.baseUrl}/listings/my';

      // Assert
      expect(url, equals('http://192.168.1.157:8001/listings/my'));

      print('✅ UT-API-017 PASSED: My listings URL constructed');
    });

    // Test 18: Upload images URL
    test('UT-API-018: Should construct upload images URL correctly', () {
      // Arrange
      final url = '${ApiService.baseUrl}/listings/upload-images';

      // Assert
      expect(url, equals('http://192.168.1.157:8001/listings/upload-images'));

      print('✅ UT-API-018 PASSED: Upload images URL constructed');
    });

    // Test 19: Profile image upload URL
    test('UT-API-019: Should construct profile image upload URL correctly', () {
      // Arrange
      final url = '${ApiService.baseUrl}/profile/upload-image';

      // Assert
      expect(url, equals('http://192.168.1.157:8001/profile/upload-image'));

      print('✅ UT-API-019 PASSED: Profile image upload URL constructed');
    });

    // Test 20: Inquiry details URL
    test('UT-API-020: Should construct inquiry details URL correctly', () {
      // Arrange
      const inquiryId = 'INQ001';
      final url = '${ApiService.baseUrl}/api/inquiries/$inquiryId';

      // Assert
      expect(url, equals('http://192.168.1.157:8001/api/inquiries/INQ001'));

      print('✅ UT-API-020 PASSED: Inquiry details URL constructed');
    });

    // Test 21: Send message URL
    test('UT-API-021: Should construct send message URL correctly', () {
      // Arrange
      const inquiryId = 'INQ002';
      final url = '${ApiService.baseUrl}/api/inquiries/$inquiryId/messages';

      // Assert
      expect(url, equals('http://192.168.1.157:8001/api/inquiries/INQ002/messages'));

      print('✅ UT-API-021 PASSED: Send message URL constructed');
    });

    // Test 22: Delete message URL
    test('UT-API-022: Should construct delete message URL correctly', () {
      // Arrange
      const inquiryId = 'INQ003';
      const messageId = 'MSG001';
      final url = '${ApiService.baseUrl}/api/inquiries/$inquiryId/messages/$messageId';

      // Assert
      expect(url, equals('http://192.168.1.157:8001/api/inquiries/INQ003/messages/MSG001'));

      print('✅ UT-API-022 PASSED: Delete message URL constructed');
    });

    // Test 23: Prediction history URL
    test('UT-API-023: Should construct prediction history URL correctly', () {
      // Arrange
      final url = '${ApiService.baseUrl}/predictions/history';

      // Assert
      expect(url, equals('http://192.168.1.157:8001/predictions/history'));

      print('✅ UT-API-023 PASSED: Prediction history URL constructed');
    });

    // Test 24: Delete prediction URL
    test('UT-API-024: Should construct delete prediction URL correctly', () {
      // Arrange
      const predictionId = 'PRED001';
      final url = '${ApiService.baseUrl}/predictions/$predictionId';

      // Assert
      expect(url, equals('http://192.168.1.157:8001/predictions/PRED001'));

      print('✅ UT-API-024 PASSED: Delete prediction URL constructed');
    });
  });

  group('Data Transformation Tests', () {

    // Test 25: Prediction data format conversion
    test('UT-API-025: Should convert frontend prediction data to backend format', () {
      // Arrange
      final frontendData = {
        'planningYear': '2025',
        'district': 'Colombo',
        'season': 'Yala',
        'temperature': '28',
        'soilType': 'Latosols',
        'landArea': '2.5',
        'crop': 'Cabbage',
      };

      // Act
      final backendData = {
        'planning_year': frontendData['planningYear'] ?? '2025',
        'location': frontendData['district'] ?? 'Colombo',
        'season': frontendData['season'] ?? 'Yala',
        'temperature': frontendData['temperature']?.toString(),
        'soil_type': frontendData['soilType'],
        'land_area': frontendData['landArea']?.toString() ?? '1.0',
        'crop': frontendData['crop'] ?? 'Cabbage',
      };

      // Assert
      expect(backendData['planning_year'], equals('2025'));
      expect(backendData['location'], equals('Colombo'));
      expect(backendData['season'], equals('Yala'));
      expect(backendData['temperature'], equals('28'));
      expect(backendData['soil_type'], equals('Latosols'));
      expect(backendData['land_area'], equals('2.5'));
      expect(backendData['crop'], equals('Cabbage'));

      print('✅ UT-API-025 PASSED: Prediction data converted correctly');
    });

    // Test 26: Default values in data conversion
    test('UT-API-026: Should apply default values when fields are null', () {
      // Arrange
      final frontendData = <String, dynamic>{};

      // Act
      final backendData = {
        'planning_year': frontendData['planningYear'] ?? '2025',
        'location': frontendData['district'] ?? 'Colombo',
        'season': frontendData['season'] ?? 'Yala',
        'land_area': frontendData['landArea']?.toString() ?? '1.0',
        'crop': frontendData['crop'] ?? 'Cabbage',
      };

      // Assert
      expect(backendData['planning_year'], equals('2025'));
      expect(backendData['location'], equals('Colombo'));
      expect(backendData['season'], equals('Yala'));
      expect(backendData['land_area'], equals('1.0'));
      expect(backendData['crop'], equals('Cabbage'));

      print('✅ UT-API-026 PASSED: Default values applied correctly');
    });
  });

  group('Request Payload Tests', () {

    // Test 27: Login request payload structure
    test('UT-API-027: Should construct login payload correctly', () {
      // Arrange
      const email = 'test@example.com';
      const password = 'password123';

      // Act
      final payload = {
        'email': email,
        'password': password,
      };

      // Assert
      expect(payload['email'], equals('test@example.com'));
      expect(payload['password'], equals('password123'));
      expect(payload.length, equals(2));

      print('✅ UT-API-027 PASSED: Login payload constructed correctly');
    });

    // Test 28: Registration payload structure
    test('UT-API-028: Should construct registration payload correctly', () {
      // Arrange
      final userData = {
        'email': 'newuser@example.com',
        'password': 'secure123',
        'firstName': 'John',
        'lastName': 'Doe',
        'userType': 'farmer',
      };

      // Assert
      expect(userData['email'], equals('newuser@example.com'));
      expect(userData['firstName'], equals('John'));
      expect(userData['lastName'], equals('Doe'));
      expect(userData['userType'], equals('farmer'));
      expect(userData.containsKey('password'), isTrue);

      print('✅ UT-API-028 PASSED: Registration payload constructed correctly');
    });

    // Test 29: Create inquiry payload
    test('UT-API-029: Should construct create inquiry payload correctly', () {
      // Arrange
      final payload = {
        'farmerId': 'FARMER001',
        'productId': 'PROD001',
        'message': 'Is this product available?',
      };

      // Assert
      expect(payload['farmerId'], equals('FARMER001'));
      expect(payload['productId'], equals('PROD001'));
      expect(payload['message'], equals('Is this product available?'));
      expect(payload.length, equals(3));

      print('✅ UT-API-029 PASSED: Create inquiry payload constructed correctly');
    });

    // Test 30: Send message payload
    test('UT-API-030: Should construct send message payload correctly', () {
      // Arrange
      final payload = {
        'message': 'Yes, it is available',
        'isImage': false,
        'imagePath': null,
      };

      // Assert
      expect(payload['message'], equals('Yes, it is available'));
      expect(payload['isImage'], isFalse);
      expect(payload['imagePath'], isNull);

      print('✅ UT-API-030 PASSED: Send message payload constructed correctly');
    });
  });

  group('Token Handling Tests', () {

    // Test 31: Token substring for logging
    test('UT-API-031: Should safely extract token substring for logging', () {
      // Arrange
      const token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ';

      // Act
      final substring = token.length >= 20 ? token.substring(0, 20) : token;

      // Assert
      expect(substring, equals('eyJhbGciOiJIUzI1NiIs'));
      expect(substring.length, equals(20));

      print('✅ UT-API-031 PASSED: Token substring extracted safely');
    });

    // Test 32: Short token handling
    test('UT-API-032: Should handle short tokens gracefully', () {
      // Arrange
      const shortToken = 'abc123';

      // Act
      final substring = shortToken.length >= 20 ? shortToken.substring(0, 20) : shortToken;

      // Assert
      expect(substring, equals('abc123'));
      expect(substring.length, lessThan(20));

      print('✅ UT-API-032 PASSED: Short token handled gracefully');
    });
  });

  group('Status Update Payload Tests', () {

    // Test 33: Update inquiry status payload
    test('UT-API-033: Should construct update status payload correctly', () {
      // Arrange
      final payload = {
        'status': 'replied',
      };

      // Assert
      expect(payload['status'], equals('replied'));
      expect(['pending', 'replied', 'closed'], contains(payload['status']));

      print('✅ UT-API-033 PASSED: Update status payload constructed correctly');
    });

    // Test 34: Valid status values
    test('UT-API-034: Should validate inquiry status values', () {
      // Arrange
      const validStatuses = ['pending', 'replied', 'closed'];

      // Assert
      expect(validStatuses, contains('pending'));
      expect(validStatuses, contains('replied'));
      expect(validStatuses, contains('closed'));
      expect(validStatuses.length, equals(3));

      print('✅ UT-API-034 PASSED: Status values validated');
    });
  });
}