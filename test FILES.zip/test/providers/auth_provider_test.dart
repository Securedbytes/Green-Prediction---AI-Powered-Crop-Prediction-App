// test/models/app_user_test.dart

import 'package:flutter_test/flutter_test.dart';
// Import your auth_provider file - adjust path as needed
// import '../../lib/providers/auth_provider.dart';

void main() {
  group('AppUser Model Tests', () {

    // Test 1: Create Farmer user with all fields
    test('UT-MOD-027: Should create Farmer AppUser with all fields', () {
      // Arrange & Act
      final farmer = AppUser(
        firstName: 'John',
        lastName: 'Doe',
        displayName: 'John Doe',
        email: 'john.farmer@example.com',
        uid: 'FARMER001',
        userType: 'farmer',
        phone: '+94771234567',
        location: 'Kandy',
        bio: 'Organic farmer with 10 years experience',
        joinDate: DateTime(2024, 1, 15),
        rating: 4.8,
        totalReviews: 25,
        farmName: 'Green Valley Farm',
        farmSize: '5 acres',
        crops: ['Rice', 'Vegetables', 'Fruits'],
        farmingExperience: '10 years',
        totalListings: 45,
        totalSales: 120,
        certification: 'Organic Certified',
      );

      // Assert
      expect(farmer.firstName, equals('John'));
      expect(farmer.lastName, equals('Doe'));
      expect(farmer.displayName, equals('John Doe'));
      expect(farmer.email, equals('john.farmer@example.com'));
      expect(farmer.uid, equals('FARMER001'));
      expect(farmer.userType, equals('farmer'));
      expect(farmer.phone, equals('+94771234567'));
      expect(farmer.location, equals('Kandy'));
      expect(farmer.bio, equals('Organic farmer with 10 years experience'));
      expect(farmer.joinDate, equals(DateTime(2024, 1, 15)));
      expect(farmer.rating, equals(4.8));
      expect(farmer.totalReviews, equals(25));
      expect(farmer.farmName, equals('Green Valley Farm'));
      expect(farmer.farmSize, equals('5 acres'));
      expect(farmer.crops, equals(['Rice', 'Vegetables', 'Fruits']));
      expect(farmer.farmingExperience, equals('10 years'));
      expect(farmer.totalListings, equals(45));
      expect(farmer.totalSales, equals(120));
      expect(farmer.certification, equals('Organic Certified'));

      print('✅ UT-MOD-027 PASSED: Farmer AppUser created with all fields');
    });

    // Test 2: Create Consumer user with all fields
    test('UT-MOD-028: Should create Consumer AppUser with all fields', () {
      // Arrange & Act
      final consumer = AppUser(
        firstName: 'Jane',
        lastName: 'Smith',
        displayName: 'Jane Smith',
        email: 'jane.consumer@example.com',
        uid: 'CONSUMER001',
        userType: 'consumer',
        phone: '+94777654321',
        location: 'Colombo',
        bio: 'Health-conscious consumer',
        joinDate: DateTime(2024, 2, 20),
        rating: 4.5,
        totalReviews: 15,
        preferences: ['Organic', 'Vegetables', 'Fruits'],
        totalOrders: 30,
        totalSpent: 45000.50,
        favoriteCrops: ['Tomato', 'Carrot', 'Cabbage'],
      );

      // Assert
      expect(consumer.firstName, equals('Jane'));
      expect(consumer.lastName, equals('Smith'));
      expect(consumer.displayName, equals('Jane Smith'));
      expect(consumer.email, equals('jane.consumer@example.com'));
      expect(consumer.uid, equals('CONSUMER001'));
      expect(consumer.userType, equals('consumer'));
      expect(consumer.preferences, equals(['Organic', 'Vegetables', 'Fruits']));
      expect(consumer.totalOrders, equals(30));
      expect(consumer.totalSpent, equals(45000.50));
      expect(consumer.favoriteCrops, equals(['Tomato', 'Carrot', 'Cabbage']));

      print('✅ UT-MOD-028 PASSED: Consumer AppUser created with all fields');
    });

    // Test 3: Create minimal AppUser (only required fields)
    test('UT-MOD-029: Should create AppUser with only required fields', () {
      // Arrange & Act
      final minimalUser = AppUser(
        uid: 'USER001',
        userType: 'farmer',
      );

      // Assert
      expect(minimalUser.uid, equals('USER001'));
      expect(minimalUser.userType, equals('farmer'));
      expect(minimalUser.firstName, isNull);
      expect(minimalUser.lastName, isNull);
      expect(minimalUser.displayName, isNull);
      expect(minimalUser.email, isNull);
      expect(minimalUser.phone, isNull);
      expect(minimalUser.location, isNull);

      print('✅ UT-MOD-029 PASSED: Minimal AppUser created successfully');
    });

    // Test 4: copyWith - update basic fields
    test('UT-MOD-030: Should update basic fields using copyWith', () {
      // Arrange
      final original = AppUser(
        firstName: 'Alice',
        lastName: 'Brown',
        displayName: 'Alice Brown',
        email: 'alice@example.com',
        uid: 'USER002',
        userType: 'consumer',
        phone: '+94771111111',
        location: 'Galle',
      );

      // Act
      final updated = original.copyWith(
        phone: '+94772222222',
        location: 'Matara',
        bio: 'Updated bio',
      );

      // Assert
      expect(updated.uid, equals('USER002')); // Unchanged
      expect(updated.firstName, equals('Alice')); // Unchanged
      expect(updated.phone, equals('+94772222222')); // Changed
      expect(updated.location, equals('Matara')); // Changed
      expect(updated.bio, equals('Updated bio')); // Changed
      expect(original.phone, equals('+94771111111')); // Original unchanged

      print('✅ UT-MOD-030 PASSED: Basic fields updated with copyWith');
    });

    // Test 5: copyWith - update farmer-specific fields
    test('UT-MOD-031: Should update farmer-specific fields using copyWith', () {
      // Arrange
      final originalFarmer = AppUser(
        uid: 'FARMER002',
        userType: 'farmer',
        displayName: 'Bob Farmer',
        farmName: 'Sunny Farm',
        farmSize: '3 acres',
        crops: ['Rice'],
        farmingExperience: '5 years',
        certification: 'Basic',
      );

      // Act
      final updatedFarmer = originalFarmer.copyWith(
        farmName: 'Sunny Valley Farm',
        farmSize: '5 acres',
        crops: ['Rice', 'Wheat', 'Corn'],
        farmingExperience: '7 years',
        certification: 'Organic Certified',
      );

      // Assert
      expect(updatedFarmer.farmName, equals('Sunny Valley Farm'));
      expect(updatedFarmer.farmSize, equals('5 acres'));
      expect(updatedFarmer.crops, equals(['Rice', 'Wheat', 'Corn']));
      expect(updatedFarmer.farmingExperience, equals('7 years'));
      expect(updatedFarmer.certification, equals('Organic Certified'));
      expect(originalFarmer.farmName, equals('Sunny Farm')); // Original unchanged

      print('✅ UT-MOD-031 PASSED: Farmer-specific fields updated with copyWith');
    });

    // Test 6: copyWith - update consumer-specific fields
    test('UT-MOD-032: Should update consumer-specific fields using copyWith', () {
      // Arrange
      final originalConsumer = AppUser(
        uid: 'CONSUMER002',
        userType: 'consumer',
        displayName: 'Carol Consumer',
        preferences: ['Organic'],
        totalOrders: 10,
        totalSpent: 15000.0,
        favoriteCrops: ['Tomato'],
      );

      // Act
      final updatedConsumer = originalConsumer.copyWith(
        preferences: ['Organic', 'Local', 'Fresh'],
        totalOrders: 15,
        totalSpent: 22500.0,
        favoriteCrops: ['Tomato', 'Carrot', 'Lettuce'],
      );

      // Assert
      expect(updatedConsumer.preferences, equals(['Organic', 'Local', 'Fresh']));
      expect(updatedConsumer.totalOrders, equals(15));
      expect(updatedConsumer.totalSpent, equals(22500.0));
      expect(updatedConsumer.favoriteCrops, equals(['Tomato', 'Carrot', 'Lettuce']));
      expect(originalConsumer.totalOrders, equals(10)); // Original unchanged

      print('✅ UT-MOD-032 PASSED: Consumer-specific fields updated with copyWith');
    });

    // Test 7: copyWith - preserve uid and userType
    test('UT-MOD-033: Should preserve uid and userType in copyWith', () {
      // Arrange
      final user = AppUser(
        uid: 'IMMUTABLE001',
        userType: 'farmer',
        displayName: 'Test User',
      );

      // Act
      final updated = user.copyWith(
        displayName: 'Updated User',
        phone: '+94771234567',
      );

      // Assert
      expect(updated.uid, equals('IMMUTABLE001')); // Never changes
      expect(updated.userType, equals('farmer')); // Never changes
      expect(updated.displayName, equals('Updated User'));

      print('✅ UT-MOD-033 PASSED: uid and userType preserved in copyWith');
    });

    // Test 8: Rating and reviews
    test('UT-MOD-034: Should handle rating and reviews correctly', () {
      // Arrange & Act
      final userWithRating = AppUser(
        uid: 'USER003',
        userType: 'farmer',
        rating: 4.75,
        totalReviews: 50,
      );

      // Assert
      expect(userWithRating.rating, equals(4.75));
      expect(userWithRating.totalReviews, equals(50));
      expect(userWithRating.rating, isA<double>());
      expect(userWithRating.totalReviews, isA<int>());

      print('✅ UT-MOD-034 PASSED: Rating and reviews handled correctly');
    });

    // Test 9: DateTime handling
    test('UT-MOD-035: Should handle DateTime joinDate correctly', () {
      // Arrange
      final joinDate = DateTime(2024, 3, 15, 10, 30, 0);

      // Act
      final user = AppUser(
        uid: 'USER004',
        userType: 'consumer',
        joinDate: joinDate,
      );

      // Assert
      expect(user.joinDate, equals(joinDate));
      expect(user.joinDate?.year, equals(2024));
      expect(user.joinDate?.month, equals(3));
      expect(user.joinDate?.day, equals(15));

      print('✅ UT-MOD-035 PASSED: DateTime joinDate handled correctly');
    });

    // Test 10: Empty lists handling
    test('UT-MOD-036: Should handle empty lists for crops and preferences', () {
      // Arrange & Act
      final farmerWithEmptyCrops = AppUser(
        uid: 'FARMER003',
        userType: 'farmer',
        crops: [],
      );

      final consumerWithEmptyPrefs = AppUser(
        uid: 'CONSUMER003',
        userType: 'consumer',
        preferences: [],
        favoriteCrops: [],
      );

      // Assert
      expect(farmerWithEmptyCrops.crops, isEmpty);
      expect(consumerWithEmptyPrefs.preferences, isEmpty);
      expect(consumerWithEmptyPrefs.favoriteCrops, isEmpty);

      print('✅ UT-MOD-036 PASSED: Empty lists handled correctly');
    });

    // Test 11: Null optional fields
    test('UT-MOD-037: Should handle null optional fields gracefully', () {
      // Arrange & Act
      final user = AppUser(
        uid: 'USER005',
        userType: 'farmer',
        firstName: null,
        lastName: null,
        phone: null,
        location: null,
        bio: null,
        joinDate: null,
        rating: null,
        totalReviews: null,
      );

      // Assert
      expect(user.firstName, isNull);
      expect(user.lastName, isNull);
      expect(user.phone, isNull);
      expect(user.location, isNull);
      expect(user.bio, isNull);
      expect(user.joinDate, isNull);
      expect(user.rating, isNull);
      expect(user.totalReviews, isNull);

      print('✅ UT-MOD-037 PASSED: Null optional fields handled gracefully');
    });

    // Test 12: Large crop list
    test('UT-MOD-038: Should handle large list of crops', () {
      // Arrange
      final largeCropList = List.generate(20, (index) => 'Crop${index + 1}');

      // Act
      final farmer = AppUser(
        uid: 'FARMER004',
        userType: 'farmer',
        crops: largeCropList,
      );

      // Assert
      expect(farmer.crops, hasLength(20));
      expect(farmer.crops![0], equals('Crop1'));
      expect(farmer.crops![19], equals('Crop20'));

      print('✅ UT-MOD-038 PASSED: Large crop list handled correctly');
    });

    // Test 13: User type validation
    test('UT-MOD-039: Should support both farmer and consumer user types', () {
      // Arrange & Act
      final farmer = AppUser(uid: 'F001', userType: 'farmer');
      final consumer = AppUser(uid: 'C001', userType: 'consumer');

      // Assert
      expect(farmer.userType, equals('farmer'));
      expect(consumer.userType, equals('consumer'));

      print('✅ UT-MOD-039 PASSED: Both user types supported');
    });

    // Test 14: copyWith with null values (no change)
    test('UT-MOD-040: Should not change fields when copyWith receives no parameters', () {
      // Arrange
      final original = AppUser(
        uid: 'USER006',
        userType: 'farmer',
        displayName: 'Original Name',
        phone: '+94771111111',
        farmName: 'Original Farm',
      );

      // Act
      final unchanged = original.copyWith();

      // Assert
      expect(unchanged.displayName, equals('Original Name'));
      expect(unchanged.phone, equals('+94771111111'));
      expect(unchanged.farmName, equals('Original Farm'));

      print('✅ UT-MOD-040 PASSED: copyWith with no params preserves values');
    });

    // Test 15: Statistics fields for farmer
    test('UT-MOD-041: Should handle farmer statistics correctly', () {
      // Arrange & Act
      final successfulFarmer = AppUser(
        uid: 'FARMER005',
        userType: 'farmer',
        totalListings: 100,
        totalSales: 250,
        rating: 4.9,
        totalReviews: 75,
      );

      // Assert
      expect(successfulFarmer.totalListings, equals(100));
      expect(successfulFarmer.totalSales, equals(250));
      expect(successfulFarmer.rating, equals(4.9));
      expect(successfulFarmer.totalReviews, equals(75));

      print('✅ UT-MOD-041 PASSED: Farmer statistics handled correctly');
    });

    // Test 16: Statistics fields for consumer
    test('UT-MOD-042: Should handle consumer statistics correctly', () {
      // Arrange & Act
      final activeConsumer = AppUser(
        uid: 'CONSUMER004',
        userType: 'consumer',
        totalOrders: 50,
        totalSpent: 125000.75,
        rating: 4.6,
        totalReviews: 20,
      );

      // Assert
      expect(activeConsumer.totalOrders, equals(50));
      expect(activeConsumer.totalSpent, equals(125000.75));
      expect(activeConsumer.rating, equals(4.6));
      expect(activeConsumer.totalReviews, equals(20));

      print('✅ UT-MOD-042 PASSED: Consumer statistics handled correctly');
    });

    // Test 17: Update rating with copyWith
    test('UT-MOD-043: Should update rating and reviews using copyWith', () {
      // Arrange
      final user = AppUser(
        uid: 'USER007',
        userType: 'farmer',
        rating: 4.5,
        totalReviews: 10,
      );

      // Act
      final updated = user.copyWith(
        rating: 4.7,
        totalReviews: 15,
      );

      // Assert
      expect(updated.rating, equals(4.7));
      expect(updated.totalReviews, equals(15));
      expect(user.rating, equals(4.5)); // Original unchanged

      print('✅ UT-MOD-043 PASSED: Rating and reviews updated with copyWith');
    });

    // Test 18: Full profile update simulation
    test('UT-MOD-044: Should handle complete profile update', () {
      // Arrange - Initial user
      final initialUser = AppUser(
        uid: 'USER008',
        userType: 'farmer',
        firstName: 'David',
        lastName: 'Miller',
        displayName: 'David Miller',
        email: 'david@example.com',
        phone: '+94771234567',
      );

      // Act - Update multiple fields
      final fullyUpdated = initialUser.copyWith(
        displayName: 'David M. Miller',
        phone: '+94777654321',
        location: 'Jaffna',
        bio: 'Experienced organic farmer',
        farmName: 'Miller\'s Organic Farm',
        farmSize: '10 acres',
        crops: ['Rice', 'Wheat', 'Vegetables'],
        farmingExperience: '15 years',
        certification: 'Organic & Sustainable',
        rating: 4.9,
        totalReviews: 50,
        totalListings: 75,
        totalSales: 200,
      );

      // Assert
      expect(fullyUpdated.uid, equals('USER008')); // Immutable
      expect(fullyUpdated.displayName, equals('David M. Miller'));
      expect(fullyUpdated.phone, equals('+94777654321'));
      expect(fullyUpdated.location, equals('Jaffna'));
      expect(fullyUpdated.bio, equals('Experienced organic farmer'));
      expect(fullyUpdated.farmName, equals('Miller\'s Organic Farm'));
      expect(fullyUpdated.farmSize, equals('10 acres'));
      expect(fullyUpdated.crops, hasLength(3));
      expect(fullyUpdated.farmingExperience, equals('15 years'));
      expect(fullyUpdated.certification, equals('Organic & Sustainable'));
      expect(fullyUpdated.rating, equals(4.9));
      expect(fullyUpdated.totalReviews, equals(50));
      expect(fullyUpdated.totalListings, equals(75));
      expect(fullyUpdated.totalSales, equals(200));

      print('✅ UT-MOD-044 PASSED: Complete profile update successful');
    });
  });
}